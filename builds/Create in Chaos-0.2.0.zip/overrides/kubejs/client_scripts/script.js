// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')